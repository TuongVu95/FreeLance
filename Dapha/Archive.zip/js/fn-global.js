const daphaHTML = $('html');
const init = () => {
    daphaHTML.addClass('daphaHTML');
}
init();